DeltaX Event scheduler fix

1. Copy `deltax_event_adaptive_manager.py` to:
   simulation_ir\deltax_event_adaptive_manager.py

2. Replace the existing:
   simulation_ir\run_deltax_event_iran_v2.cmd
   with the supplied file.

3. Test manually:
   simulation_ir\run_deltax_event_iran_v2.cmd

4. Inspect log:
   Get-Content simulation_ir\deltax_event_iran_v2_scheduler.log -Tail 120

What this changes:
- Existing Iran/Event Playbook still runs every scheduler cycle.
- Adaptive strategy is NOT run again and cannot create new adaptive entries.
- Adaptive manager only watches already-recorded adaptive positions.
- Before 15:50 ET it does nothing.
- At/after 15:50 ET it closes adaptive positions recorded in state.
- Exit results are written to `adaptive_exits` in the same state JSON.
